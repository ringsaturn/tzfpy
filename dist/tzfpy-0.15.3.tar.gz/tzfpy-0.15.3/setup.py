from setuptools import setup

setup(name="tzfpy", url="https://github.com/ringsaturn/tzfpy")
